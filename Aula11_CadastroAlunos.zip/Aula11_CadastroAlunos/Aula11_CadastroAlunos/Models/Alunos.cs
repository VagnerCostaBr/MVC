﻿namespace Aula11_CadastroAlunos.Models
{
    public class Alunos
    {
        public int AlunosId { get; set; }
        public string? AlunosNome { get; set; }
        public int Idade { get; set; }
        public string? Endereco { get; set; }
        public string? CEP { get; set; }
        public string? Turma { get; set; }

    }
}
