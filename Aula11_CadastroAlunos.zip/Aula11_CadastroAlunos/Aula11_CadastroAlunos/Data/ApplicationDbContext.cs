﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Aula11_CadastroAlunos.Models;

namespace Aula11_CadastroAlunos.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Aula11_CadastroAlunos.Models.Alunos> Alunos { get; set; } = default!;
    }
}
