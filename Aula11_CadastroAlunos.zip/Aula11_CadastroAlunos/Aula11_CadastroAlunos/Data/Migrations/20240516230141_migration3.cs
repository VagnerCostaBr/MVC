﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Aula11_CadastroAlunos.Data.Migrations
{
    /// <inheritdoc />
    public partial class migration3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AlunosNome",
                table: "Alunos",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Endereco",
                table: "Alunos",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AlunosNome",
                table: "Alunos");

            migrationBuilder.DropColumn(
                name: "Endereco",
                table: "Alunos");
        }
    }
}
